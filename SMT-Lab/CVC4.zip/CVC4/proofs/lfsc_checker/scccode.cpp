#include "scccode.h"

void init_compiled_scc(){

}

Expr* run_compiled_scc( Expr* p, std::vector< Expr* >& args ){
  return NULL;
}


