package cvc3;

import java.util.*;

public class ProofMut extends Proof {
    // jni methods
    
    
    /// Constructor

    // create embedded object
    public ProofMut(Object ProofMut, EmbeddedManager embeddedManager) {
	super(ProofMut, embeddedManager);
    }

    
    /// API (mutable)
}
