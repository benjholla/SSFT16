package cvc3;

import java.util.*;

public class TheoremMut extends Theorem {
    // jni methods
    
    
    /// Constructor

    // create embedded object
    public TheoremMut(Object TheoremMut, EmbeddedManager embeddedManager) {
	super(TheoremMut, embeddedManager);
    }

    
    /// API (mutable)
}
