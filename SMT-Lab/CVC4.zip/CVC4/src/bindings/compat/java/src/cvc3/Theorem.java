package cvc3;

import java.util.*;

public class Theorem extends Embedded {
    // jni methods

    /// Constructor

    public Theorem(Object Theorem, EmbeddedManager embeddedManager) {
	super(Theorem, embeddedManager);
    }


    /// API (immutable)

}
