package cvc3;

import java.util.*;

public class OpMut extends Op {
    // jni methods
    
    
    /// Constructor

    // create embedded object
    public OpMut(Object OpMut, EmbeddedManager embeddedManager) {
	super(OpMut, embeddedManager);
    }

    
    /// API (mutable)
}
