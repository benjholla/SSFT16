package cvc3;

import java.util.*;

public class ExprMut extends Expr {
    // jni methods
    
    
    /// Constructor

    // create embedded object
    public ExprMut(Object ExprMut, EmbeddedManager embeddedManager) {
	super(ExprMut, embeddedManager);
    }

    
    /// API (mutable)
}
