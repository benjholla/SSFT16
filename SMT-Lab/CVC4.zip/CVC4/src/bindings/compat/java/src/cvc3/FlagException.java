package cvc3;

import java.util.*;

public class FlagException extends Cvc3Exception {

    private final static long serialVersionUID = 1L;

    public FlagException(String message) {
	super(message);
    }
}
